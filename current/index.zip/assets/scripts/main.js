$(document).ready(function(){
  $(document).on("change", ".contacts-file input", function() {
    let file = $(this)[0].files[0].name;
    $(".contacts-file").hide();
    $(".contacts__file").prepend(file);
    $(".contacts__file").show().css("display", "flex");
  });
  $(document).on("click", ".contacts__file svg", function() {
    $(".contacts-file input")[0].value = "";
    $(".contacts__file").hide();
    $(".contacts-file").show();
  });
});